#!/bin/bash

#-----------------------------------------------------#
# Para los algoritmos de ordenacion cuadraticos
INICIO=4 # Tamanio inicial
FINAL=32768 # Tamanio final
INCRE=2   # Tamanio de incremento
#-----------------------------------------------------#
g++ -o traspuesta_fb traspuesta_fb.cpp -std=gnu++0x

#--------------------------------------------------------------------#
# EJECUCIÓN ALGORITMO DE ORDENACIÓN traspuesta_fb
rm res/traspuesta_fb.dat
for ((tam=$INICIO; tam<=$FINAL; tam*=$INCRE)) do
	./traspuesta_fb $tam >> res/traspuesta_fb.dat
done


#include <iostream>
#include <vector>
#include <cstdlib>
#include <chrono>
using namespace std;

//Devuelve el contenedor con menor peso
int seleccion(const vector <int> &c) {
    int min=c[0];
    int minpos=0;
    int p;
    for(int i=1; i<c.size(); i++) {
        p=c[i];
        if(min >=p) {
            min=p;
            minpos=i;
        }
    }
    return minpos;
}

//Devuelve un vector con los contenedores que se pueden cargar
vector <int> crearBuque(vector <int> c ,int k) {
    vector<int> s;
    int obj;
    int x;
    int peso_actual=0;
    while(!c.empty() && peso_actual<=k) {
        x= seleccion(c);
        obj =c[x];
        c[x]=c[c.size()-1];
        c.pop_back();
        if((peso_actual + obj) <= k) {
            s.push_back(obj);
            peso_actual+=obj;
        }
    }
    return s;
}

//Generar el vector
vector<int> genera(int n) {
    vector<int> T(n);
    srand(time(0));
    for(int i=0; i<n; i++) {
        T[i]=(rand()%100)+1;
    }
    return T;
}

int main(int argc, char *argv[]) {

    if(argc != 2) {
        cerr << "Formato " << argv[0] << " <numero contenedores>" << "\n";
        return -1;
    }
    
    int n = atoi(argv[1]);
    int tamMax=40*n; //tamaño de los contenedores en funcion del nuemero de contenedores

    vector <int> buque;
    buque=genera(n); //crea el buque con todas las cargas

    vector <int> salida;

    clock_t tantes = clock();
    salida=crearBuque(buque,tamMax);//crea un vector con el maximo de cargas posibles
    clock_t tdespues = clock();

    cout << n << " " << (double)(tdespues - tantes) / CLOCKS_PER_SEC  << endl;
/*
    for(int i=0;i<salida.size();i++)
    	cout<<salida[i]<<" ";
    cout<<endl;
*/
}

// Compilacion:
// g++ -std=gnu++0x tsp.cpp -o tsp  <-- Sin optimizacion
// g++ -O3 -std=gnu++0x tsp.cpp -o tsp-O3  <-- Con optimizacion


#include <iostream>
#include <fstream>
#include <map>
#include <vector>
#include <cmath>
#include <cstring>
#include <ctime>
#include <chrono>
#include <stdlib.h>

using namespace std::chrono;

high_resolution_clock::time_point tantes, tdespues;
duration<double> transcurrido;

using namespace std;

/**
 * @brief Lee de un archivo y extrae la informacion de las ciudades
 * 
 * @param archivo nombre del archivo a leer
 * @param ciudades objeto de tipo map donde se guarda la informacion de las ciudades
 */
void LeerCiudades(string archivo, map<int, pair<double, double>> & ciudades) {
    ifstream flujo;
    char cadena[70];
    int N;

    flujo.open(archivo);
    if (flujo) {
        
        flujo >> cadena >> cadena;
        
        if (cadena[0] == 'a') {
            flujo.getline(cadena, 70);
            flujo.getline(cadena, 70);
            flujo.getline(cadena, 70);
            
            flujo >> cadena >> N;

            flujo.getline(cadena, 70);
            flujo.getline(cadena, 70);
            flujo.getline(cadena, 70);
        }
        
        else {
            flujo.getline(cadena, 70);
            flujo.getline(cadena, 70);
            flujo.getline(cadena, 70);

            flujo >> cadena >> N;
            
            flujo.getline(cadena, 70);
            flujo.getline(cadena, 70);
            flujo.getline(cadena, 70);
            flujo.getline(cadena, 70);
        }
        
        pair<double, double> punto;
        int num_punto;
        
        for (int i=0; i<N; i++) {
            flujo >> num_punto >> punto.first >> punto.second;
            ciudades[num_punto] = punto;
        }

        flujo.close();
    }
}

/**
 * @brief Almacena en el mapa ciudades con coordenadas aleatorias
 * 
 * @param ciudades mapa donde se almacenan las ciudades
 * @param numero_ciudades dimension del mapa de ciudades
 */
void AlmacenarCiudadesAleatorias(map<int, pair<double, double>> & ciudades, int numero_ciudades) {
    pair<double, double> punto;
    srand(time(NULL));
    
    for (int i=1; i<=numero_ciudades; i++) {
        punto.first = (double) (rand() % 10000);
        punto.second = (double) (rand() % 10000);
        ciudades[i] = punto;
    }
}

/**
 * @brief Calcula la distacia entre dos puntos
 * 
 * @param p1 punto de la primera ciudad
 * @param p2 punto de la segunda ciudad
 * @return double 
 */
double Distancia(const pair<double, double> & p1, const pair<double, double> & p2) {
    return sqrt(pow(p2.first-p1.first,2) + pow(p2.second-p1.second,2));
}

/**
 * @brief Calcula las distancias que hay entre ciudades y las almacena en una matriz
 * 
 * @param m matriz donde se almacenan los resultados
 * @param ciudades objeto de tipo map que contiene la informacion de las ciudades
 */
void CalculaDistanciaCiudades(double **m, const map<int, pair<double, double>> & ciudades) {
    for (int i=1; i<ciudades.size()+1; i++) {
        for (int j=1; j<ciudades.size()+1; j++) {
            m[i][j] = Distancia(ciudades.at(i), ciudades.at(j));
        }
    }
}

/**
 * @brief Obtiene el indice de las ciudades
 * 
 * @param n numero de ciudades
 * @return vector<int> 
 */
vector<int> ObtenerCiudades(int n) {
    vector<int> salida;
    for (int i=1; i<n+1; i++) {
        salida.push_back(i);
    }
    return salida;
}

/**
 * @brief Indica si el indice de una ciudad esta en un vector
 * 
 * @param v vector donde se busca el indice de la ciudad
 * @param ciudad indice de la ciudad
 * @return true si la ciudad se encuentra en el vector
 * @return false si la ciudad no se encuentra en el vector
 */
bool EstaCiudad(const vector<int> & v, int ciudad) {
    bool enc = false;
    for (int i=1; i<v.size()+1 && !enc; i++) {
        if (v[i] == ciudad) {
            enc = true;
        }
    }
    return enc;
}

/**
 * @brief Calcula el recorrido de todas las ciudades basado en cercania
 * 
 * @param ciudades ciudades a recorrer
 * @param distancias matriz que cotiene la distancia que hay entre cada dos ciudades
 * @param recorrido vector en el que se almacena el recorrido de las ciudades
 */
void ViajanteDeComercio(vector<int> ciudades, double **distancias, vector<int> & recorrido, double & distancia_total) {
    double distancia_menor;
    int siguiente_ciudad, indice;

    // Seleccionamos la primera ciudad como ciudad actual (la primera del recorrido)
    recorrido.push_back(ciudades.front());
    int ciudad_actual = ciudades.front();
    ciudades.erase(ciudades.begin());
    
    // Recorremos el vector de ciudades comparando la distancia de cada ciudad respecto a 'ciudad_actual'
    while (!ciudades.empty()) {

        distancia_menor = 10000000000000;
        siguiente_ciudad = ciudades[0];
        
        for (int i=0; i<ciudades.size(); i++)  {

            // Comprobamos en la matriz de distancias si la distancia con la siguiente ciudad es menor
            if (distancias[ciudad_actual][ciudades[i]] < distancia_menor) {
                distancia_menor = distancias[ciudad_actual][ciudades[i]];   // Actualizamos la distancia menor
                siguiente_ciudad = ciudades[i];                             // Actualizamos la siguiente ciudad
                indice = i;                                                 // Guardamos el indice para borrarlo del vector de ciudades
            }

        }

        // Introducimos el indice de la ciudad mas cercana a la ciudad actual en el vector resultado
        recorrido.push_back(siguiente_ciudad);

        // Eliminamos la ciudad mas cercana a la ciudad actual del vector de ciudades para no volver a recorrerla
        ciudades.erase(ciudades.begin()+indice);

        // Establecemos la siguiente ciudad como ciudad actual
        ciudad_actual = siguiente_ciudad;

        // Acumulamos la distancia total recorrida
        distancia_total += distancia_menor;
    }
    recorrido.push_back(recorrido.front());
    distancia_total += distancias[ciudad_actual][recorrido.front()];    // Añadimos la distancia entre la ultima ciudad y la primera (vuelta al origen)
}


int main (int argc, char** argv) {

    vector<int> recorrido, ciudades;
    map<int, pair<double, double>> mapa_ciudades;
    double distancia_total = 0;

    if (argc != 2) {
        cout << "Error: debe indicar el archivo de datos de entrada" << endl;
        exit(EXIT_FAILURE);
    }

    // Leemos los datos de entrada del archivo pasado como argumento
    LeerCiudades(argv[1], mapa_ciudades);

    // int num = atoi(argv[1]);
    // AlmacenarCiudadesAleatorias(mapa_ciudades, num);    // Para medir eficiencia del algoritmo

    // Reservamos memoria dinamica para la matriz que almacena las distancias entre ciudades
    double** distancias = new double*[mapa_ciudades.size()+1];
	for(int i=0; i<mapa_ciudades.size()+1; ++i) distancias[i] = new double[mapa_ciudades.size()+1];

    // Calculamos las distancias entre ciudades y las almacenamos en la matriz
    CalculaDistanciaCiudades(distancias, mapa_ciudades);

    // Obtenemos los indices de las ciudades
    ciudades = ObtenerCiudades(mapa_ciudades.size());

    // Ejecucion del algortimo del Viajante de Comercio
    // tantes = high_resolution_clock::now();
    ViajanteDeComercio(ciudades, distancias, recorrido, distancia_total);
    // tdespues = high_resolution_clock::now();

    // transcurrido = duration_cast<duration<double>>(tdespues - tantes);
    // cout << transcurrido.count() << endl;

    // Resultado del algoritmo: Recorrido de las ciudades escogido
    // cout << "El recorrido tomado es: " << endl;
    for (int i=0; i<recorrido.size(); i++) {
        cout << recorrido[i] << " " << mapa_ciudades[recorrido[i]].first << " " << mapa_ciudades[recorrido[i]].second << endl;
    }

    // cout << endl << "La distancia recorrida es: " << distancia_total << endl;

    for(int i=0; i<mapa_ciudades.size()+1; ++i) delete[] distancias[i];
    delete[] distancias;

    // cout << (double)(tdespues - tantes) / CLOCKS_PER_SEC << endl;

}
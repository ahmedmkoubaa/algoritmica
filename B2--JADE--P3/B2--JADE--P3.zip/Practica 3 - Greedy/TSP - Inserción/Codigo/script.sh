#!/bin/bash

INI=500
FINAL=100000
INCRE=7500


g++ -o insercion_damian insercion_damian.cpp -O3;
mkdir res;
rm res/insercion_damian.dat;

for ((tam=$INI; tam<$FINAL; tam+=$INCRE)) do
	./insercion_damian $tam >> res/insercion_damian.dat;
done
